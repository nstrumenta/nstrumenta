.. _multimedia-and-graphics-index:

=======================
Multimedia and Graphics
=======================

This section contains articles about Emscripten's support for graphics and audio APIs.


.. toctree::
   :maxdepth: 1
   
   EGL-Support-in-Emscripten
   OpenGL-support
   
