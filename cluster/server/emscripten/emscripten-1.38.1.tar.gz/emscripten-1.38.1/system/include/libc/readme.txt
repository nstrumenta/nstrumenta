
These are musl headers, see system/lib/libc/musl/ for details and copyright info

