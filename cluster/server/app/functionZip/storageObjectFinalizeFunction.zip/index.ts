export { storageObjectFinalize } from './src/storageObjectFinalize'
