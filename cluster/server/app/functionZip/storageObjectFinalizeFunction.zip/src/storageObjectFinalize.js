"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.storageObjectFinalize = void 0;
const firestore_1 = require("@google-cloud/firestore");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const keyfile = process.env.GOOGLE_APPLICATION_CREDENTIALS;
if (keyfile == undefined)
    throw new Error('GOOGLE_APPLICATION_CREDENTIALS not set to path of keyfile');
const serviceAccount = JSON.parse(fs_1.default.readFileSync(keyfile, 'utf8'));
const firestore = new firestore_1.Firestore({
    projectId: serviceAccount.project_id,
    credentials: {
        client_email: serviceAccount.client_email,
        private_key: serviceAccount.private_key,
    },
});
const storageObjectFinalize = async (file) => {
    await firestore
        .doc(file.name)
        .set({
        name: path_1.default.basename(file.name),
        lastModified: Date.now(),
        filePath: file.name,
        size: file.size,
        file,
    });
};
exports.storageObjectFinalize = storageObjectFinalize;
//# sourceMappingURL=storageObjectFinalize.js.map