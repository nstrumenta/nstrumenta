# Cloud API Functions
storageObjectFinalize is to be deployed as a gcloud function triggered on changes to the bucket - it updates the firestore db.