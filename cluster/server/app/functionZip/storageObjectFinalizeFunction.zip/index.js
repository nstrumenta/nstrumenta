"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.storageObjectFinalize = void 0;
var storageObjectFinalize_1 = require("./src/storageObjectFinalize");
Object.defineProperty(exports, "storageObjectFinalize", { enumerable: true, get: function () { return storageObjectFinalize_1.storageObjectFinalize; } });
//# sourceMappingURL=index.js.map