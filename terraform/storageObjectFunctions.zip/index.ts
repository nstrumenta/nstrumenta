export { storageObjectFinalize } from './src/storageObjectFinalize'
export { storageObjectDelete } from './src/storageObjectDelete'
