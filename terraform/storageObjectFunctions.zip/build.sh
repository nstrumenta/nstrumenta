#!/bin/bash -xe
npm run build
